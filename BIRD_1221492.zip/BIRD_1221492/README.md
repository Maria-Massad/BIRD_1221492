# BIRD - Birzeit Integrated Router Design

Plain SystemVerilog verification environment for BIRD, a packet-based routing block.
Course project for ENCS5337 - Chip Design Verification.
Birzeit University, Second Semester 2025/2026.

## Overview

BIRD receives packets on a single input interface and routes them to one of two outputs:

- Local traffic: forwarded directly to the local output.
- Remote traffic: received as fragments, accumulated, reordered, merged, and emitted as one packet with a regenerated CRC16.

Invalid packets are silently dropped and counted in drop_cnt.
Routing is driven by a 32-bit cfg sideband word.

## Repository structure

- design/              : bird.sv design under test
- verif/cfg/           : optional configuration files
- verif/env/           : package, packet, driver, monitors, scoreboard, assertions, coverage, generators, environment
- verif/if/            : bird_if.sv interface and clocking blocks
- verif/seq/           : sequence files
- verif/tb/            : bird_tb.sv top-level testbench
- verif/tests/         : test classes
- sim/                 : simulation scripts or generated simulation files
- coverage/code_coverage : code coverage output directory
- coverage/func_coverage : functional coverage output directory
- test_plan/           : TESTPLAN.xlsx

## Compile example

```bash
vcs -f flist.f -l coverage/reports/vcs_compile.log -o simv
```
