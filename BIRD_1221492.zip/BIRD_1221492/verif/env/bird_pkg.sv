//=============================================================================
// bird_pkg.sv
// Shared package for the plain SystemVerilog BIRD verification environment.
// Keeps the existing separated file structure while providing one canonical
// bird_packet type for drivers, monitors, generators, sequences, and tests.
//=============================================================================
`ifndef BIRD_PKG_SV
`define BIRD_PKG_SV

package bird_pkg;

  typedef enum bit {
    LOCAL_PKT  = 1'b0,
    REMOTE_PKT = 1'b1
  } pkt_type_e;

  `include "bird_packet.sv"

endpackage : bird_pkg

`endif
