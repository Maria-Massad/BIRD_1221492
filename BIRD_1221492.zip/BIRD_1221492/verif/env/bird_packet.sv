`ifndef BIRD_PACKET_SV
`define BIRD_PACKET_SV

class bird_packet;

  localparam bit LOCAL_TRAFFIC  = 1'b0;
  localparam bit REMOTE_TRAFFIC = 1'b1;

  // Configuration fields
  rand pkt_type_e   pkt_type;
  rand bit          traffic_type;
  rand bit [7:0]    payload_len;
  rand bit [4:0]    frag_num;
  rand bit [4:0]    seq_num;
  rand bit [6:0]    rsvd_7_1;
  rand bit [2:0]    rsvd_23_21;
  rand bit [2:0]    rsvd_31_29;

  // Data fields
  rand byte unsigned payload[];
  bit [15:0] crc16;
  bit [31:0] cfg;
  bit [31:0] cfg_word;

  function new();
    pkt_type     = LOCAL_PKT;
    traffic_type = LOCAL_TRAFFIC;
    payload_len  = 8'd1;
    frag_num     = 5'd1;
    seq_num      = 5'd1;
    rsvd_7_1     = 7'd0;
    rsvd_23_21   = 3'd0;
    rsvd_31_29   = 3'd0;
    payload      = new[1];
    payload[0]   = 8'h00;
    crc16        = 16'h0000;
    cfg          = 32'h0000_0000;
    cfg_word     = 32'h0000_0000;
  endfunction

  constraint c_type_sync {
    (pkt_type == LOCAL_PKT)  -> (traffic_type == LOCAL_TRAFFIC);
    (pkt_type == REMOTE_PKT) -> (traffic_type == REMOTE_TRAFFIC);
  }

  constraint c_valid_basic {
    payload_len inside {[8'd1:8'd255]};
    frag_num    inside {[5'd1:5'd31]};
    seq_num     inside {[5'd1:5'd31]};
    rsvd_7_1   == 7'd0;
    rsvd_23_21 == 3'd0;
    rsvd_31_29 == 3'd0;
    payload.size() == payload_len;
  }

  constraint c_local_rules {
    if (pkt_type == LOCAL_PKT) {
      frag_num == 5'd1;
    }
  }

  function void sync_type_from_pkt_type();
    traffic_type = (pkt_type == REMOTE_PKT) ? REMOTE_TRAFFIC : LOCAL_TRAFFIC;
  endfunction

  function void sync_pkt_type_from_traffic();
    pkt_type = traffic_type ? REMOTE_PKT : LOCAL_PKT;
  endfunction

  // Pack fields into the 32-bit cfg word.
  // pkt_type is the public test API; traffic_type is kept for older env files.
  function void build_cfg();
    sync_type_from_pkt_type();

    cfg = {
      rsvd_31_29,
      seq_num,
      rsvd_23_21,
      frag_num,
      payload_len,
      rsvd_7_1,
      traffic_type
    };

    cfg_word = cfg;
  endfunction

  static function bit [15:0] compute_crc16(input byte unsigned payload_arr[]);
    bit [15:0] crc;
    crc = 16'hFFFF;

    foreach (payload_arr[i]) begin
      crc ^= {payload_arr[i], 8'h00};
      for (int b = 0; b < 8; b++) begin
        if (crc[15])
          crc = (crc << 1) ^ 16'h1021;
        else
          crc = crc << 1;
      end
    end

    return crc;
  endfunction

  function bit [15:0] calculate_crc16();
    return compute_crc16(payload);
  endfunction

  function void finalize_packet();
    build_cfg();
    crc16 = calculate_crc16();
  endfunction

  function void post_randomize();
    finalize_packet();
  endfunction

  function void make_local(
    input bit [4:0]      sequence_number,
    input byte unsigned  data[]
  );
    pkt_type     = LOCAL_PKT;
    traffic_type = LOCAL_TRAFFIC;
    payload_len  = data.size();
    frag_num     = 5'd1;
    seq_num      = sequence_number;
    rsvd_7_1     = 7'd0;
    rsvd_23_21   = 3'd0;
    rsvd_31_29   = 3'd0;
    payload      = new[data.size()];
    foreach (data[i]) payload[i] = data[i];
    finalize_packet();
  endfunction

  function void make_remote_fragment(
    input bit [4:0]      sequence_number,
    input bit [4:0]      fragment_number,
    input byte unsigned  data[]
  );
    pkt_type     = REMOTE_PKT;
    traffic_type = REMOTE_TRAFFIC;
    payload_len  = data.size();
    frag_num     = fragment_number;
    seq_num      = sequence_number;
    rsvd_7_1     = 7'd0;
    rsvd_23_21   = 3'd0;
    rsvd_31_29   = 3'd0;
    payload      = new[data.size()];
    foreach (data[i]) payload[i] = data[i];
    finalize_packet();
  endfunction

  function void make_invalid_seq_zero(input byte unsigned data[]);
    make_local(5'd1, data);
    seq_num = 5'd0;
    finalize_packet();
  endfunction

  function void make_invalid_frag_zero(input byte unsigned data[]);
    make_remote_fragment(5'd1, 5'd1, data);
    frag_num = 5'd0;
    finalize_packet();
  endfunction

  function void make_invalid_payload_len_zero();
    pkt_type     = LOCAL_PKT;
    traffic_type = LOCAL_TRAFFIC;
    payload_len  = 8'd0;
    frag_num     = 5'd1;
    seq_num      = 5'd1;
    rsvd_7_1     = 7'd0;
    rsvd_23_21   = 3'd0;
    rsvd_31_29   = 3'd0;
    payload      = new[0];
    finalize_packet();
  endfunction

  function void make_invalid_reserved_bits(input byte unsigned data[]);
    make_local(5'd1, data);
    rsvd_7_1 = 7'b000_0001;
    finalize_packet();
  endfunction

  function void print(string tag = "BIRD_PACKET");
    $display("[%0t] %s", $time, tag);
    $display("  pkt_type     = %s", (pkt_type == REMOTE_PKT) ? "REMOTE" : "LOCAL");
    $display("  traffic_type = %0d", traffic_type);
    $display("  payload_len  = %0d", payload_len);
    $display("  frag_num     = %0d", frag_num);
    $display("  seq_num      = %0d", seq_num);
    $display("  rsvd_7_1     = 0x%02h", rsvd_7_1);
    $display("  rsvd_23_21   = 0x%01h", rsvd_23_21);
    $display("  rsvd_31_29   = 0x%01h", rsvd_31_29);
    $display("  cfg          = 0x%08h", cfg);
    $display("  crc16        = 0x%04h", crc16);
    $write  ("  payload      = ");
    foreach (payload[i]) $write("%02h ", payload[i]);
    $write("\n");
  endfunction

  static function bit [15:0] compute_crc16_q(input byte unsigned payload_q[$]);
    bit [15:0] crc;
    crc = 16'hFFFF;

    foreach (payload_q[i]) begin
      crc ^= {payload_q[i], 8'h00};
      for (int b = 0; b < 8; b++) begin
        if (crc[15])
          crc = (crc << 1) ^ 16'h1021;
        else
          crc = crc << 1;
      end
    end

    return crc;
  endfunction

endclass

`endif
