import bird_pkg::*;
//=============================================================================
// bird_backpressure_test.sv � M4
// Tests backpressure � spec �3.2
//=============================================================================
`ifndef BIRD_BACKPRESSURE_TEST_SV
`define BIRD_BACKPRESSURE_TEST_SV

class bird_backpressure_test;

  bird_env env;

  function new(bird_env env);
    this.env = env;
  endfunction

  task run();
    bird_packet pkt;
    bird_packet frag1;
    bird_packet frag2;
    bit [15:0]  drop_before;

    $display("============================================================");
    $display("TEST START: bird_backpressure_test");
    $display("============================================================");

    env.prepare_for_test();
    drop_before = env.vif.drop_cnt;

    $display("[BP] Local backpressure test");
    env.driver.set_local_ready(1'b0);
    pkt = env.local_gen.create_basic_local_packet();
    env.coverage.sample_packet(pkt);
    env.driver.drive_packet(pkt);
    env.wait_cycles(5);
    env.coverage.sample_backpressure(
      env.vif.local_vld, env.vif.local_rdy,
      env.vif.remote_vld, env.vif.remote_rdy);
    env.driver.set_local_ready(1'b1);
    env.wait_cycles(20);

    if (env.vif.drop_cnt === drop_before)
      $display("[BP] PASS LOCAL BP: no drops during local backpressure");
    else
      $error("[BP] FAIL LOCAL BP: drop_cnt changed expected=%0d actual=%0d",
             drop_before, env.vif.drop_cnt);

    if (!env.vif.remote_vld)
      $display("[BP] PASS LOCAL BP: no remote output");
    else
      $error("[BP] FAIL LOCAL BP: unexpected remote output");

    $display("[BP] Remote backpressure test");
    env.prepare_for_test();
    drop_before = env.vif.drop_cnt;

    env.driver.set_remote_ready(1'b0);
    frag1 = env.remote_gen.create_two_fragment_packet_frag1();
    frag2 = env.remote_gen.create_two_fragment_packet_frag2();
    env.coverage.sample_packet(frag1);
    env.coverage.sample_packet(frag2);
    env.driver.drive_packet(frag1);
    env.driver.idle(2);
    env.driver.drive_packet(frag2);
    env.wait_cycles(5);
    env.coverage.sample_backpressure(
      env.vif.local_vld, env.vif.local_rdy,
      env.vif.remote_vld, env.vif.remote_rdy);
    env.driver.set_remote_ready(1'b1);
    env.wait_cycles(30);

    if (env.vif.drop_cnt === drop_before)
      $display("[BP] PASS REMOTE BP: no drops during remote backpressure");
    else
      $error("[BP] FAIL REMOTE BP: drop_cnt changed expected=%0d actual=%0d",
             drop_before, env.vif.drop_cnt);

    if (!env.vif.local_vld)
      $display("[BP] PASS REMOTE BP: no local output");
    else
      $error("[BP] FAIL REMOTE BP: unexpected local output");

    $display("============================================================");
    $display("TEST END: bird_backpressure_test");
    $display("============================================================");
  endtask

endclass

`endif