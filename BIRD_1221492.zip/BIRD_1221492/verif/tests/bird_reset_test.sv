import bird_pkg::*;
//=============================================================================
// bird_reset_test.sv � M3
// Tests reset behavior � spec �9
// Converted to env-based architecture
//=============================================================================
`ifndef BIRD_RESET_TEST_SV
`define BIRD_RESET_TEST_SV

class bird_reset_test;

  bird_env env;

  function new(bird_env env);
    this.env = env;
  endfunction

  task run();
    bird_packet pkt;
    $display("============================================================");
    $display("TEST START: bird_reset_test");
    $display("============================================================");

    env.prepare_for_test();

    // PRO_005: Basic reset � spec �9
    $display("[RESET] PRO_005: Basic reset behavior");
    env.vif.rst_n = 1'b0;
    env.wait_cycles(5);

    if (env.vif.local_vld === 1'b0)
      $display("[RESET] PASS PRO_005: local_vld=0 during reset");
    else
      $error("[RESET] FAIL PRO_005: local_vld high during reset");

    if (env.vif.remote_vld === 1'b0)
      $display("[RESET] PASS PRO_005: remote_vld=0 during reset");
    else
      $error("[RESET] FAIL PRO_005: remote_vld high during reset");

    if (env.vif.drop_cnt === 16'd0)
      $display("[RESET] PASS PRO_005: drop_cnt=0 during reset");
    else
      $error("[RESET] FAIL PRO_005: drop_cnt=%0d during reset", env.vif.drop_cnt);

    // release reset
    env.vif.rst_n = 1'b1;
    env.wait_cycles(5);

    // PRO_006: Reset mid-packet � spec �9
    $display("[RESET] PRO_006: Reset mid-packet");
    begin
      byte unsigned d[];
      d = new[8];
      foreach (d[i]) d[i] = byte'(i);
      pkt = new();
      pkt.make_remote_fragment(5'd1, 5'd1, d);
      // drive first 2 bytes then reset
      env.driver.drive_input_byte(pkt.payload[0], pkt.cfg);
      env.driver.drive_input_byte(pkt.payload[1], pkt.cfg);
    end
    env.vif.rst_n = 1'b0;
    env.wait_cycles(3);

    if (env.vif.local_vld === 1'b0 && env.vif.remote_vld === 1'b0)
      $display("[RESET] PASS PRO_006: outputs cleared mid-packet reset");
    else
      $error("[RESET] FAIL PRO_006: outputs not cleared after mid-packet reset");

    if (env.vif.drop_cnt === 16'd0)
      $display("[RESET] PASS PRO_006: drop_cnt=0 after reset");
    else
      $error("[RESET] FAIL PRO_006: drop_cnt=%0d after reset", env.vif.drop_cnt);

    env.vif.rst_n = 1'b1;
    env.wait_cycles(5);

    // PRO_007: Reset clears drop_cnt � spec �9
    $display("[RESET] PRO_007: Reset clears drop_cnt");
    begin
      byte unsigned d[];
      d = new[2]; d[0]=8'hDE; d[1]=8'hAD;
      pkt = new();
      pkt.make_local(5'd1, d);
      pkt.seq_num = 5'd0;  // invalid ? drop
      pkt.finalize_packet();
      env.driver.drive_packet(pkt);
      // send flush to commit drop_cnt
      begin
        bird_packet flush = new();
        byte unsigned fd[];
        fd = new[2]; fd[0]=8'hAA; fd[1]=8'hBB;
        flush.make_local(5'd1, fd);
        env.driver.drive_packet(flush);
      end
      env.wait_cycles(20);
    end

    if (env.vif.drop_cnt > 0)
      $display("[RESET] PASS PRO_007: drop_cnt=%0d before reset", env.vif.drop_cnt);
    else
      $error("[RESET] FAIL PRO_007: drop_cnt did not increment before reset");

    env.vif.rst_n = 1'b0;
    env.wait_cycles(3);

    if (env.vif.drop_cnt === 16'd0)
      $display("[RESET] PASS PRO_007: drop_cnt cleared to 0 by reset");
    else
      $error("[RESET] FAIL PRO_007: drop_cnt=%0d not cleared", env.vif.drop_cnt);

    env.vif.rst_n = 1'b1;
    env.wait_cycles(5);

    // PRO_008: Normal operation resumes after reset � spec �9
    $display("[RESET] PRO_008: Normal operation resumes after reset");
    env.prepare_for_test();
    pkt = env.local_gen.create_basic_local_packet();
    env.coverage.sample_packet(pkt);
    env.driver.drive_packet(pkt);
    env.wait_cycles(20);

    if (env.vif.drop_cnt === 16'd0)
      $display("[RESET] PASS PRO_008: normal operation resumed, no drops");
    else
      $error("[RESET] FAIL PRO_008: unexpected drops after reset");

    // PRO_012: in_rdy during reset � spec �9
    $display("[RESET] PRO_012: in_rdy behavior during reset");
    env.vif.rst_n = 1'b0;
    env.wait_cycles(2);

    // spec �9 says outputs deasserted � in_rdy is always 1 (combinational)
    // so this is a potential DUT bug if in_rdy goes low during reset
    if (env.vif.in_rdy === 1'b1)
      $display("[RESET] INFO PRO_012: in_rdy=1 during reset (DUT always-1 behavior)");
    else
      $display("[RESET] INFO PRO_012: in_rdy=0 during reset");

    env.vif.rst_n = 1'b1;
    env.wait_cycles(5);

    if (env.vif.in_rdy === 1'b1)
      $display("[RESET] PASS PRO_012: in_rdy=1 after reset released");
    else
      $error("[RESET] FAIL PRO_012: in_rdy not reasserted after reset");

    $display("============================================================");
    $display("TEST END: bird_reset_test");
    $display("============================================================");
  endtask

endclass

`endif