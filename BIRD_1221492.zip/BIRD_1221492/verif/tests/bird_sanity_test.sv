//=============================================================================
// bird_sanity_test.sv
// Basic local packet tests according to the BIRD specification.
// Covers: LOC_001, LOC_002, LOC_003, LOC_004, LOC_005, LOC_006,
//         LOC_008, LOC_009
//=============================================================================
`ifndef BIRD_SANITY_TEST_SV
`define BIRD_SANITY_TEST_SV

class bird_sanity_test;

  bird_env env;

  function new(bird_env env);
    this.env = env;
  endfunction

  task check_no_drop_increment(string name, bit [15:0] drop_before);
    if (env.vif.drop_cnt === drop_before)
      $display("[SANITY] PASS %s: drop_cnt did not increment", name);
    else
      $error("[SANITY] FAIL %s: drop_cnt changed before=%0d after=%0d",
             name, drop_before, env.vif.drop_cnt);
  endtask

  task run();
    bird_packet pkt;
    bit [15:0] drop_before;

    $display("============================================================");
    $display("TEST START: bird_sanity_test");
    $display("============================================================");

    env.prepare_for_test();

    // -- LOC_001: Basic local packet forwarding ------------
    // Spec section 6: local payload is forwarded to local output.
    $display("[SANITY] LOC_001: Basic local forwarding");
    drop_before = env.vif.drop_cnt;
    pkt = env.local_gen.create_basic_local_packet();
    env.coverage.sample_packet(pkt);
    $display("[SANITY] Sending: cfg=0x%08h crc=0x%04h payload=AA BB CC DD",
             pkt.cfg, pkt.crc16);
    env.driver.drive_packet(pkt);
    env.wait_cycles(30);
    check_no_drop_increment("LOC_001", drop_before);

    // -- LOC_009: Local not routed to remote ---------------
    // Spec section 6: local traffic goes to local output only.
    $display("[SANITY] LOC_009: Local not routed to remote");
    if (!env.vif.remote_vld)
      $display("[SANITY] PASS LOC_009: remote_vld stayed 0");
    else
      $error("[SANITY] FAIL LOC_009: remote_vld went high for local packet");

    // -- LOC_006: FRAG_NUM=1 valid case -------------------
    // Spec section 6: FRAG_NUM shall be 1 for local traffic.
    $display("[SANITY] LOC_006: FRAG_NUM=1 valid");
    env.prepare_for_test();
    drop_before = env.vif.drop_cnt;
    pkt = env.local_gen.create_basic_local_packet();
    env.coverage.sample_packet(pkt);
    env.driver.drive_packet(pkt);
    env.wait_cycles(20);
    check_no_drop_increment("LOC_006", drop_before);

    // -- LOC_008: Minimum payload (1 byte) -----------------
    // Spec section 2.1: minimum payload length is 1 byte.
    $display("[SANITY] LOC_008: Min payload 1 byte");
    env.prepare_for_test();
    drop_before = env.vif.drop_cnt;
    pkt = env.local_gen.create_min_payload_local_packet();
    env.coverage.sample_packet(pkt);
    env.driver.drive_packet(pkt);
    env.wait_cycles(20);
    check_no_drop_increment("LOC_008", drop_before);

    // -- LOC_002: Maximum payload (255 bytes) --------------
    // Spec section 2.1: maximum payload length is 255 bytes.
    $display("[SANITY] LOC_002: Max payload 255 bytes");
    env.prepare_for_test();
    drop_before = env.vif.drop_cnt;
    pkt = env.local_gen.create_max_payload_local_packet();
    env.coverage.sample_packet(pkt);
    env.driver.drive_packet(pkt);
    env.wait_cycles(300);
    check_no_drop_increment("LOC_002", drop_before);

    // -- LOC_004: CRC16 passthrough unchanged --------------
    // Spec section 6: input CRC16 is forwarded unchanged for local traffic.
    $display("[SANITY] LOC_004: CRC16 passthrough");
    env.prepare_for_test();
    drop_before = env.vif.drop_cnt;
    pkt = env.local_gen.create_basic_local_packet();
    env.coverage.sample_packet(pkt);
    $display("[SANITY] Expected CRC16 = 0x%04h", pkt.crc16);
    env.driver.drive_packet(pkt);
    env.wait_cycles(20);
    check_no_drop_increment("LOC_004", drop_before);

    // -- LOC_005: SEQ_NUM has no functional effect ---------
    // Spec section 6: SEQ_NUM identifies the local packet but has no
    // functional impact on local routing. Any non-zero SEQ_NUM is valid.
    $display("[SANITY] LOC_005: SEQ_NUM has no functional effect for local traffic");
    begin
      byte unsigned d[];
      int seq_values[4];
      d = new[2];
      d[0] = 8'hC0;
      d[1] = 8'hC1;

      seq_values[0] = 1;
      seq_values[1] = 2;
      seq_values[2] = 5;
      seq_values[3] = 31;

      for (int i = 0; i < 4; i++) begin
        int seq;
        seq = seq_values[i];
        env.prepare_for_test();
        drop_before = env.vif.drop_cnt;
        pkt = env.local_gen.create_local_packet(seq[4:0], d);
        env.coverage.sample_packet(pkt);
        env.driver.drive_packet(pkt);
        env.wait_cycles(25);
        check_no_drop_increment($sformatf("LOC_005 seq=%0d", seq), drop_before);
      end
    end

    // -- LOC_003: Randomized local packets -----------------
    // Spec section 6: multiple valid local packets are forwarded correctly.
    $display("[SANITY] LOC_003: Randomized local packets");
    begin
      byte unsigned d[];
      int pass_count;
      pass_count = 0;

      for (int i = 0; i < 5; i++) begin
        int len;
        bit [4:0] seq;
        len = 2 + i;
        seq = bit'(i + 1);
        d = new[len];
        for (int j = 0; j < len; j++) d[j] = byte'(8'h10 + i*16 + j);

        env.prepare_for_test();
        drop_before = env.vif.drop_cnt;
        pkt = env.local_gen.create_local_packet(seq, d);
        env.coverage.sample_packet(pkt);
        env.driver.drive_packet(pkt);
        env.wait_cycles(30);

        if (env.vif.drop_cnt === drop_before) begin
          $display("[SANITY] PASS LOC_003[%0d]: seq=%0d len=%0d forwarded with no drop",
                   i, seq, len);
          pass_count++;
        end
        else begin
          $error("[SANITY] FAIL LOC_003[%0d]: seq=%0d len=%0d caused drop increment before=%0d after=%0d",
                 i, seq, len, drop_before, env.vif.drop_cnt);
        end
      end

      if (pass_count == 5)
        $display("[SANITY] PASS LOC_003: all 5 randomized local packets had no drops");
      else
        $error("[SANITY] FAIL LOC_003: only %0d/5 randomized local packets had no drops", pass_count);
    end

    $display("============================================================");
    $display("TEST END: bird_sanity_test");
    $display("============================================================");
  endtask

endclass

`endif
