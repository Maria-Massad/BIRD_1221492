import bird_pkg::*;
//=============================================================================
// bird_proto_full_test.sv  M4
// Closes remaining PRO_* test plan gaps:
//   PRO_001  transfer only when vld=1 and rdy=1
//   PRO_003  cfg sampled on first payload byte only
//   PRO_009  reset while outputting on local interface
//   PRO_010  reset while outputting on remote interface
//   PRO_011  multiple resets in a row
//   PRO_013  cfg stability during entire fragment
//=============================================================================
`ifndef BIRD_PROTO_FULL_TEST_SV
`define BIRD_PROTO_FULL_TEST_SV

class bird_proto_full_test;

  bird_env env;

  function new(bird_env env);
    this.env = env;
  endfunction

  task run();
    bird_packet pkt;
    byte unsigned d[];

    $display("============================================================");
    $display("TEST START: bird_proto_full_test");
    $display("============================================================");

    //-------------------------------------------------------------
    // PRO_001: transfer only happens when in_vld=1 AND in_rdy=1.
    // in_rdy is a DUT output, so the TB cannot force it low directly.
    // This confirms that the standard handshake (drive_input_byte
    // asserts in_vld and waits for in_rdy, exactly as every other
    // test does) results in exactly one accepted byte per handshake
    // cycle, cross-checked end-to-end by the scoreboard.
    //-------------------------------------------------------------
    $display("[PROTO_FULL] PRO_001: handshake-gated transfer");
    env.prepare_for_test();
    begin
      bit [15:0] drop_before;
      drop_before = env.vif.drop_cnt;
      d = new[3]; d[0] = 8'h61; d[1] = 8'h62; d[2] = 8'h63;
      pkt = new();
      pkt.make_local(5'd1, d);
      env.coverage.sample_packet(pkt);
      env.driver.drive_packet(pkt);
      env.wait_cycles(20);
      if (env.vif.drop_cnt === drop_before)
        $display("[PROTO_FULL] PASS PRO_001: packet fully and correctly handshaken (scoreboard clean)");
      else
        $error("[PROTO_FULL] FAIL PRO_001: unexpected drop during handshake-gated transfer");
    end

    //-------------------------------------------------------------
    // PRO_003: cfg is sampled only on the first payload byte of a
    // fragment. Corrupt cfg AFTER the first byte (flip a reserved
    // bit) and confirm the packet still completes using the
    // originally-sampled (valid) cfg, proving later cfg changes
    // are ignored by the DUT.
    //-------------------------------------------------------------
    $display("[PROTO_FULL] PRO_003: cfg sampled on first byte only");
    env.prepare_for_test();
    begin
      bit [15:0] drop_before;
      bit [31:0] good_cfg;
      bit [31:0] corrupted_cfg;

      drop_before = env.vif.drop_cnt;

      pkt = new();
      d = new[2]; d[0] = 8'h71; d[1] = 8'h72;
      pkt.make_local(5'd1, d);
      env.coverage.sample_packet(pkt);

      good_cfg      = pkt.cfg;
      corrupted_cfg = pkt.cfg | 32'h0000_0002; // set a reserved bit (cfg[1])

      // Drive first byte with the valid cfg (this is what gets sampled)
      env.driver.drive_input_byte(pkt.payload[0], good_cfg);
      // Drive remaining bytes with a corrupted cfg -- DUT must ignore this
      env.driver.drive_input_byte(pkt.payload[1],  corrupted_cfg);
      env.driver.drive_input_byte(pkt.crc16[15:8], corrupted_cfg);
      env.driver.drive_input_byte(pkt.crc16[7:0],  corrupted_cfg);
      env.driver.idle(5);
      env.wait_cycles(20);

      if (env.vif.drop_cnt === drop_before)
        $display("[PROTO_FULL] PASS PRO_003: packet processed using first-byte cfg, later corruption ignored");
      else
        $error("[PROTO_FULL] FAIL PRO_003: drop_cnt changed -- DUT may be re-sampling cfg mid-fragment");
    end

    //-------------------------------------------------------------
    // PRO_013: cfg stability across an entire multi-byte fragment
    // (the well-behaved / positive-direction counterpart to PRO_003).
    //-------------------------------------------------------------
    $display("[PROTO_FULL] PRO_013: cfg stability during entire fragment");
    env.prepare_for_test();
    begin
      bit [15:0] drop_before;
      drop_before = env.vif.drop_cnt;
      d = new[4]; d[0] = 8'h81; d[1] = 8'h82; d[2] = 8'h83; d[3] = 8'h84;
      pkt = new();
      pkt.make_local(5'd1, d);
      env.coverage.sample_packet(pkt);
      env.driver.drive_packet(pkt); // driver already holds cfg stable across the fragment
      env.wait_cycles(20);
      if (env.vif.drop_cnt === drop_before)
        $display("[PROTO_FULL] PASS PRO_013: packet processed correctly with cfg held stable");
      else
        $error("[PROTO_FULL] FAIL PRO_013: unexpected drop with stable cfg");
    end

    //-------------------------------------------------------------
    // PRO_009: reset while outputting on the local interface.
    //-------------------------------------------------------------
    $display("[PROTO_FULL] PRO_009: reset during local output");
    env.prepare_for_test();
    begin
      int timeout;
      env.driver.set_local_ready(1'b0);
      d = new[6];
      foreach (d[i]) d[i] = byte'(8'h90 + i);
      pkt = new();
      pkt.make_local(5'd1, d);
      env.coverage.sample_packet(pkt);
      env.driver.drive_packet(pkt);

      timeout = 0;
      while (!env.vif.local_vld && (timeout < 60)) begin
        env.wait_cycles(1);
        timeout++;
      end

      if (!env.vif.local_vld)
        $error("[PROTO_FULL] FAIL PRO_009: local_vld never asserted, cannot test mid-output reset");
      else begin
        env.vif.rst_n = 1'b0;
        env.wait_cycles(3);
        if (!env.vif.local_vld)
          $display("[PROTO_FULL] PASS PRO_009: local_vld deasserted immediately on reset");
        else
          $error("[PROTO_FULL] FAIL PRO_009: local_vld still high after reset asserted");
      end

      env.vif.rst_n = 1'b1;
      env.driver.set_local_ready(1'b1);
      env.wait_cycles(5);
      env.prepare_for_test();
    end

    //-------------------------------------------------------------
    // PRO_010: reset while outputting on the remote interface.
    //-------------------------------------------------------------
    $display("[PROTO_FULL] PRO_010: reset during remote output");
    env.prepare_for_test();
    begin
      int timeout;
      bird_packet frag1, frag2;
      bird_remote_generator rg;
      rg = new();

      env.driver.set_remote_ready(1'b0);
      frag1 = rg.create_two_fragment_packet_frag1();
      frag2 = rg.create_two_fragment_packet_frag2();
      env.coverage.sample_packet(frag1);
      env.coverage.sample_packet(frag2);
      env.driver.drive_packet(frag1);
      env.driver.drive_packet(frag2);

      timeout = 0;
      while (!env.vif.remote_vld && (timeout < 80)) begin
        env.wait_cycles(1);
        timeout++;
      end

      if (!env.vif.remote_vld)
        $error("[PROTO_FULL] FAIL PRO_010: remote_vld never asserted, cannot test mid-output reset");
      else begin
        env.vif.rst_n = 1'b0;
        env.wait_cycles(3);
        if (!env.vif.remote_vld)
          $display("[PROTO_FULL] PASS PRO_010: remote_vld deasserted immediately on reset");
        else
          $error("[PROTO_FULL] FAIL PRO_010: remote_vld still high after reset asserted");
      end

      env.vif.rst_n = 1'b1;
      env.driver.set_remote_ready(1'b1);
      env.wait_cycles(5);
      env.prepare_for_test();
    end

    //-------------------------------------------------------------
    // PRO_011: multiple resets in a row, confirming recovery each time.
    //-------------------------------------------------------------
    $display("[PROTO_FULL] PRO_011: multiple resets in a row");
    for (int r = 0; r < 4; r++) begin
      env.vif.rst_n = 1'b0;
      env.wait_cycles(3);

      if (!env.vif.local_vld && !env.vif.remote_vld && (env.vif.drop_cnt == 16'd0))
        $display("[PROTO_FULL] PASS PRO_011[%0d]: reset cleared visible state", r);
      else
        $error("[PROTO_FULL] FAIL PRO_011[%0d]: reset did not clear state", r);

      env.vif.rst_n = 1'b1;
      env.wait_cycles(5);
      env.prepare_for_test();

      d = new[2]; d[0] = byte'(8'hB0 + r); d[1] = byte'(8'hC0 + r);
      pkt = new();
      pkt.make_local(5'd1, d);
      env.coverage.sample_packet(pkt);
      env.driver.drive_packet(pkt);
      env.wait_cycles(20);

      if (env.vif.drop_cnt === 16'd0)
        $display("[PROTO_FULL] PASS PRO_011[%0d]: normal operation resumed after reset", r);
      else
        $error("[PROTO_FULL] FAIL PRO_011[%0d]: unexpected drop after reset recovery", r);
    end

    $display("============================================================");
    $display("TEST END: bird_proto_full_test");
    $display("============================================================");
  endtask

endclass

`endif

